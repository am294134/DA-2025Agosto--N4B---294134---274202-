package com.example.obligatorio_dda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObligatorioDdaApplicationTests {

	@Test
	void contextLoads() {
	}

}
