package com.example.obligatorio_dda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObligatorioDdaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObligatorioDdaApplication.class, args);
	}

}
